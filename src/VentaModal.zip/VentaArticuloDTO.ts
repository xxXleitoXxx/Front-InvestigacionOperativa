export interface VentaArticuloDTO {
  id: number;
  articuloDTO: {
    id: number;
  };
  cantArtVentDTO: number;
  montoArt: number;
}